# THE LAST FREQUENCY — Pixel Horror Demo

Prototype game horor psikologis 2D side-scrolling dengan gaya pixel art, dibuat menggunakan HTML5 Canvas, CSS, dan JavaScript vanilla.

## Jalankan game
- Download repository atau ZIP ini.
- Ekstrak file.
- Buka `index.html` di browser modern (Chrome, Edge, Firefox).
- Klik **Mulai Permainan**.

Tidak membutuhkan instalasi, build tools, atau server.

## Kontrol
| Tombol | Aksi |
|---|---|
| A / D atau ← / → | Berjalan |
| SHIFT | Berlari |
| F | Nyalakan/matikan senter |
| E | Interaksi dengan radio / lanjut dialog |
| ESC | Pause / lanjut |

## Struktur folder
```text
the-last-frequency/
├── index.html
├── style.css
├── README.md
├── src/
│   └── game.js
└── assets/
    ├── sprites/
    │   └── (tempat sprite sheet tambahan)
    └── audio/
        └── (tempat musik dan sound effect)
```

## Fitur demo
- Pixel-art character dengan animasi idle, walking, dan running yang digambar melalui Canvas.
- Side-scrolling camera yang mengikuti pemain.
- Lingkungan Kampung Laras: rumah, pepohonan, kabel listrik, jalan basah, dan lampu.
- Hujan, kabut bergerak, glow, vignette, dan scanline.
- Senter yang bisa dinyalakan/dimatikan.
- Radio interaktif dan dialog pembuka cerita.
- UI objective, status sinyal, pause, dan toast.

## Upload ke GitHub Pages
1. Buat repository baru, misalnya `the-last-frequency`.
2. Upload seluruh isi folder ini ke root repository.
3. Buka **Settings → Pages**.
4. Pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
6. Setelah deployment selesai, game bisa dibuka melalui URL GitHub Pages yang ditampilkan GitHub.

## Catatan pengembangan
Sprite karakter dan lingkungan pada prototype ini dibuat secara prosedural dengan bentuk-bentuk pixel di Canvas agar demo dapat langsung dimainkan tanpa file gambar eksternal. Folder `assets/sprites` dan `assets/audio` disiapkan untuk pengembangan aset berikutnya.
