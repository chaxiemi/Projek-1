Simpan sprite sheet PNG di folder ini saat aset gambar eksternal ditambahkan.
