(() => {
'use strict';
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;
const W = canvas.width, H = canvas.height;
const keys = new Set();
const ui = {
  start: document.getElementById('startOverlay'),
  startBtn: document.getElementById('startBtn'),
  pause: document.getElementById('pauseOverlay'),
  dialogue: document.getElementById('dialogue'),
  speaker: document.getElementById('speaker'),
  dialogueText: document.getElementById('dialogueText'),
  objective: document.getElementById('objective'),
  status: document.getElementById('statusText'),
  toast: document.getElementById('toast')
};
let started = false, paused = false, flashlight = true, dialogueIndex = -1;
let cameraX = 0, frame = 0, last = 0, toastTimer = 0, radioFound = false;
const worldWidth = 2600, groundY = 438;
const player = {x:150,y:0,vx:0,dir:1,state:'idle',anim:0};
const radio = {x:1770,y:0};
const rain = Array.from({length:150},()=>({x:Math.random()*W,y:Math.random()*H,s:2+Math.random()*4}));
const fog = Array.from({length:12},(_,i)=>({x:i*250,y:340+Math.random()*80,w:100+Math.random()*130,a:.025+Math.random()*.035}));
const dialogues = [
  ['UNKNOWN TRANSMISSION','Nara... kalau kamu masih mendengarku, jangan pulang ke rumah.'],
  ['UNKNOWN TRANSMISSION','Mereka sudah tahu kamu mengingatnya.'],
  ['NARA','Itu... suara Ibu? Tapi bagaimana mungkin?'],
  ['UNKNOWN TRANSMISSION','Cari frekuensinya. Rumah dengan lampu yang masih menyala.'],
  ['NARA','Siapa kamu? Kenapa tahu namaku?'],
  ['RADIO','03:17. Jangan biarkan rekaman itu selesai.']
];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function line(x1,y1,x2,y2,c,w=1){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();}
function worldRect(x,y,w,h,c){rect(x-cameraX,y,w,h,c);}
function drawSky(){
  const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#101a2b');g.addColorStop(.55,'#182638');g.addColorStop(1,'#25313b');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  // distant moon glow
  const glow=ctx.createRadialGradient(760-cameraX*.12,115,5,760-cameraX*.12,115,170);
  glow.addColorStop(0,'#8b9b9a44');glow.addColorStop(1,'#8b9b9a00');ctx.fillStyle=glow;ctx.fillRect(0,0,W,310);
  rect(0,265,W,175,'#17232c');
}
function drawMountains(){
  for(let layer=0;layer<3;layer++){
    const speed=.12+layer*.12, base=300+layer*34, col=['#182b34','#15242d','#111e27'][layer];
    ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(0,H);
    for(let x=-100;x<W+150;x+=100){const wx=x+((cameraX*speed)%200);ctx.lineTo(wx,base-Math.sin((x+layer*71)*.017)*28-Math.cos(x*.009)*17); }
    ctx.lineTo(W,H);ctx.closePath();ctx.fill();
  }
}
function drawTree(x,y,scale=1){
  x-=cameraX*.8;if(x<-100||x>W+100)return;
  rect(x-5*scale,y-78*scale,10*scale,78*scale,'#101b20');
  rect(x-28*scale,y-90*scale,56*scale,28*scale,'#142923');
  rect(x-20*scale,y-112*scale,42*scale,30*scale,'#172f2a');
  rect(x-9*scale,y-128*scale,22*scale,25*scale,'#1b352e');
  rect(x-23*scale,y-87*scale,8*scale,7*scale,'#254036');
}
function drawHouse(x,y,w=180,h=145,lit=false){
  x-=cameraX;if(x<-w-20||x>W+30)return;
  // shadow and body
  rect(x+8,y+10,w,h,'#0a1218');rect(x,y,w,h,'#273039');rect(x+8,y+9,w-16,h-12,'#303b40');
  // roof
  ctx.fillStyle='#101920';ctx.beginPath();ctx.moveTo(x-12,y+12);ctx.lineTo(x+w*.5,y-47);ctx.lineTo(x+w+12,y+12);ctx.closePath();ctx.fill();
  rect(x+15,y+13,w-30,8,'#46504c');
  // wooden wall slats
  for(let i=18;i<w-12;i+=18)rect(x+i,y+25,3,h-35,'#26343a');
  // windows
  for(const wx of [x+30,x+w-57]){
    rect(wx-3,y+42,49,48,'#111b23');rect(wx,y+45,43,42,lit?'#bd9461':'#1a303a');
    if(lit){rect(wx+4,y+50,35,32,'#d7a56b');rect(wx+19,y+45,4,42,'#725b49');rect(wx,y+63,43,3,'#725b49');}
    else {rect(wx+19,y+45,4,42,'#35434a');rect(wx,y+64,43,3,'#35434a');}
  }
  // door
  rect(x+w*.43,y+91,35,h-91,'#111a20');rect(x+w*.43+5,y+96,25,h-100,'#3b3530');rect(x+w*.43+26,y+116,3,3,'#d2a66e');
  // porch
  rect(x-8,y+h-8,w+16,9,'#111b20');
}
function drawEnvironment(){
  drawSky();drawMountains();
  // far trees
  for(let i=0;i<18;i++)drawTree(i*190+70,405,.65);
  drawHouse(300,292,180,146,false);
  drawHouse(650,275,205,163,false);
  drawHouse(1110,300,170,138,true);
  drawHouse(1480,278,220,160,false);
  drawHouse(1980,292,180,146,false);
  // utility poles and cables
  for(let i=0;i<7;i++){
    const x=i*420+180-cameraX;if(x>-30&&x<W+30){rect(x,205,5,240,'#111b21');rect(x-30,205,65,5,'#182229');}
  }
  // ground layers
  rect(0,groundY,W,H-groundY,'#171f23');rect(0,groundY,W,5,'#34403d');
  for(let i=0;i<90;i++){
    const x=((i*83-cameraX*.98)%W+W)%W;rect(x,groundY+15+(i*17)%90,2,2,i%3?'#34403a':'#536052');
  }
  // puddles
  for(let i=0;i<14;i++){const x=(i*113-cameraX*.9%W+W)%W;rect(x,groundY+30+(i*19)%60,25+(i%4)*9,2,'#42545a');rect(x+5,groundY+33+(i*19)%60,12,1,'#718083');}
  // grass tufts
  for(let i=0;i<48;i++){const x=(i*61-cameraX%W+W)%W;rect(x,groundY-3,2,5,'#506044');rect(x+3,groundY-5,2,6,'#384e3c');}
  // radio location sign
  const rx=radio.x-cameraX;
  if(rx>-100&&rx<W+100){
    rect(rx-23,groundY-38,46,36,'#111a20');rect(rx-18,groundY-33,36,26,'#6c5140');
    rect(rx-14,groundY-29,28,3,'#c59b6c');rect(rx-14,groundY-21,20,2,'#2a1f1a');
    rect(rx-8,groundY-14,16,4,'#201915');
    if(!radioFound){rect(rx-2,groundY-48,4,4,'#d9b17b');}
  }
}
function drawRain(dt){
  ctx.strokeStyle='#9ebbc7';ctx.globalAlpha=.32;ctx.lineWidth=1;
  for(const p of rain){p.x-=70*dt;p.y+=230*p.s/4*dt;if(p.y>H){p.y=-10;p.x=Math.random()*W;}if(p.x<0)p.x=W;
    ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-4,p.y+11);ctx.stroke();}
  ctx.globalAlpha=1;
}
function drawFog(dt){
  fog.forEach((f,i)=>{f.x-=12*dt;if(f.x+f.w<0)f.x=W+100;ctx.globalAlpha=f.a;ctx.fillStyle='#b1c0bb';ctx.beginPath();ctx.ellipse(f.x,f.y,f.w,12+i%4*4,0,0,Math.PI*2);ctx.fill();});
  ctx.globalAlpha=1;
}
function pxCharacter(x,y,state,dir,anim){
  // Pixel-art Nara, 24x42-ish, drawn in chunky rectangles
  const bob=state==='walk'?Math.round(Math.sin(anim)*2):state==='run'?Math.round(Math.sin(anim)*3):0;
  const leg=state==='idle'?0:Math.round(Math.sin(anim)*5);
  ctx.save();ctx.translate(Math.round(x),Math.round(y+bob));ctx.scale(dir,1);
  // shadow
  ctx.globalAlpha=.35;ctx.fillStyle='#05090d';ctx.fillRect(-14,0,28,4);ctx.globalAlpha=1;
  // hair back and head
  rect(-8,-39,16,15,'#171820');rect(-10,-35,4,12,'#171820');rect(6,-34,4,13,'#171820');
  // face
  rect(-6,-37,12,12,'#c28d70');rect(-8,-34,3,8,'#a96f5c');
  // hair fringe
  rect(-8,-41,16,5,'#171820');rect(-7,-36,5,3,'#171820');rect(2,-38,6,3,'#171820');
  // eye
  rect(3,-32,2,2,'#20232a');
  // jacket torso
  rect(-9,-25,18,16,'#344d58');rect(-11,-23,4,12,'#263e49');rect(7,-23,4,12,'#263e49');
  rect(-5,-24,3,14,'#60747a');rect(2,-23,3,13,'#263943');
  // backpack
  rect(-13,-24,5,13,'#795c43');rect(-13,-21,4,6,'#a07a55');
  // arms
  const armSwing=state==='walk'?Math.round(Math.sin(anim+Math.PI)*3):0;
  rect(-12,-21+armSwing,4,11,'#bd896e');rect(8,-21-armSwing,4,11,'#bd896e');
  // pants and animated legs
  rect(-8,-10,7,7,'#242c39');rect(1,-10,7,7,'#242c39');
  if(state==='idle'){rect(-7,-5,6,5,'#1a202a');rect(2,-5,6,5,'#1a202a');}
  else{
    rect(-7,-6+leg,6,6,'#1a202a');rect(2,-6-leg,6,6,'#1a202a');
    rect(-8,-1+leg,8,3,'#111820');rect(1,-1-leg,8,3,'#111820');
  }
  // tiny jacket zipper highlight
  rect(0,-22,1,8,'#c0a37b');
  ctx.restore();
}
function drawFlashlight(){
  const px=player.x-cameraX, py=groundY-23;
  if(!flashlight)return;
  const beam=ctx.createRadialGradient(px+player.dir*100,py-18,8,px+player.dir*100,py-18,230);
  beam.addColorStop(0,'#e4d5a51b');beam.addColorStop(.55,'#d4c49a0a');beam.addColorStop(1,'#d4c49a00');
  ctx.fillStyle=beam;ctx.fillRect(0,150,W,350);
  ctx.save();ctx.globalCompositeOperation='screen';ctx.fillStyle='#c8c7a20b';ctx.beginPath();ctx.moveTo(px,py-12);ctx.lineTo(px+player.dir*260,py-105);ctx.lineTo(px+player.dir*260,py+65);ctx.closePath();ctx.fill();ctx.restore();
}
function drawRadioGlow(){
  const x=radio.x-cameraX;
  if(Math.abs(x-(player.x-cameraX))<330&&!radioFound){
    const g=ctx.createRadialGradient(x,groundY-35,3,x,groundY-35,100);g.addColorStop(0,'#d6a66b24');g.addColorStop(1,'#d6a66b00');ctx.fillStyle=g;ctx.fillRect(x-100,groundY-135,200,200);
  }
}
function draw(){
  ctx.clearRect(0,0,W,H);
  drawEnvironment();drawRadioGlow();
  // lightning-like distant lamp flicker
  if(Math.sin(frame*.025)>0.997){rect(0,0,W,H,'#c5d4d41a');}
  drawFlashlight();
  pxCharacter(player.x-cameraX,groundY,player.state,player.dir,player.anim);
  drawFog(0.016);drawRain(0.016);
  // subtle film grain pixel specks
  for(let i=0;i<25;i++){const x=(i*173+frame*3)%W,y=(i*97+frame*2)%H;rect(x,y,1,1,'#dbe2df12');}
}
function showToast(text){
  ui.toast.textContent=text;ui.toast.classList.remove('hidden');toastTimer=2.2;
}
function openDialogue(index){
  dialogueIndex=index;ui.speaker.textContent=dialogues[index][0];ui.dialogueText.textContent=dialogues[index][1];ui.dialogue.classList.remove('hidden');
}
function closeDialogue(){ui.dialogue.classList.add('hidden');dialogueIndex=-1;}
function interact(){
  if(dialogueIndex>=0){if(dialogueIndex<dialogues.length-1)openDialogue(dialogueIndex+1);else{closeDialogue();radioFound=true;ui.objective.textContent='OBJECTIVE: SIGNAL RECOVERED';ui.status.textContent='SIGNAL: CONNECTED';showToast('FREKUENSI TERSIMPAN — CHAPTER 01 COMPLETE');}return;}
  if(!radioFound&&Math.abs(player.x-radio.x)<90){
    radioFound=true;ui.objective.textContent='OBJECTIVE: LISTEN TO THE TRANSMISSION';ui.status.textContent='SIGNAL: CONNECTED';openDialogue(0);return;
  }
  if(!radioFound){showToast('RADIO SIGNAL DETECTED — KEEP WALKING');}
  else showToast('THE RADIO IS SILENT. FOR NOW.');
}
function update(dt){
  if(!started||paused||dialogueIndex>=0)return;
  const left=keys.has('ArrowLeft')||keys.has('a')||keys.has('A');
  const right=keys.has('ArrowRight')||keys.has('d')||keys.has('D');
  const moving=left!==right, running=keys.has('Shift');
  const speed=running?205:115;
  player.vx=moving?(right?1:-1)*speed:0;
  if(moving)player.dir=right?1:-1;
  player.x=clamp(player.x+player.vx*dt,35,worldWidth-40);
  player.state=moving?(running?'run':'walk'):'idle';
  player.anim+=dt*(running?15:9);
  cameraX=clamp(player.x-W*.38,0,worldWidth-W);
  if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)ui.toast.classList.add('hidden');}
  const nearRadio=Math.abs(player.x-radio.x)<115;
  if(nearRadio&&!radioFound)ui.objective.textContent='OBJECTIVE: PRESS E TO INSPECT THE RADIO';
  else if(!radioFound)ui.objective.textContent='OBJECTIVE: FOLLOW THE ROAD';
}
function loop(t){
  const dt=Math.min((t-last)/1000||0,.04);last=t;frame++;
  update(dt);draw();requestAnimationFrame(loop);
}
ui.startBtn.addEventListener('click',()=>{started=true;ui.start.classList.add('hidden');showToast('FIND THE RADIO. FOLLOW THE ROAD.');});
window.addEventListener('keydown',e=>{
  if(['ArrowLeft','ArrowRight',' ','Shift'].includes(e.key))e.preventDefault();
  keys.add(e.key);
  if(e.repeat)return;
  if(e.key==='Escape'&&started&&dialogueIndex<0){paused=!paused;ui.pause.classList.toggle('hidden',!paused);}
  if((e.key==='e'||e.key==='E')&&started&&!paused)interact();
  if((e.key==='f'||e.key==='F')&&started&&!paused){flashlight=!flashlight;showToast(flashlight?'FLASHLIGHT: ON':'FLASHLIGHT: OFF');}
});
window.addEventListener('keyup',e=>keys.delete(e.key));
window.addEventListener('blur',()=>keys.clear());
requestAnimationFrame(loop);
})();