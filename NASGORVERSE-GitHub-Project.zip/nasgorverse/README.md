# NASGORVERSE — Wajan Nusantara 🍳🇮🇩

Game memasak nasi goreng khas Indonesia berbasis browser, dibuat dengan HTML, CSS, dan JavaScript murni.

## Cara menjalankan
1. Download atau clone repository ini.
2. Buka `index.html` di browser.
3. Klik **Mulai Masak** dan cocokkan bahan, bumbu, serta topping dengan pesanan pelanggan.

## Cara upload ke GitHub
1. Buat repository baru bernama `nasgorverse`.
2. Upload `index.html` dan `README.md`.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
6. Tunggu proses selesai. GitHub akan memberikan tautan game yang bisa dibagikan.

## Fitur
- Sistem pesanan acak.
- Pilihan bahan utama, bumbu, dan topping.
- Timer 60 detik.
- Skor, koin, dan combo.
- Tampilan responsif untuk desktop dan ponsel.

## Teknologi
HTML5 · CSS3 · Vanilla JavaScript

Dibuat sebagai proyek kreatif bertema kuliner Nusantara.
